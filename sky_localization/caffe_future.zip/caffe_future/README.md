This is a pre-release Caffe branch for fully convolutional networks. This includes unmerged PRs and no guarantees.

Everything here is subject to change, including the history of this branch.

Consider PR #2016 for reducing memory usage.

See `future.sh` for details.
