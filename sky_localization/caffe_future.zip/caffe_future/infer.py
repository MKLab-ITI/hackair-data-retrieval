from __future__ import print_function
import numpy as np
import sys
import time
from PIL import Image
caffe_root = './'
sys.path.insert(0, caffe_root +'python')
import caffe



# FUNCTIONS

# load image, switch to BGR, subtract mean, and make dims C x H x W for Caffe
def loadImage(imageFile):
  im = Image.open(imageFile)
  in_ = np.array(im, dtype=np.float32)
  in_ = in_[:,:,::-1]
  in_ -= np.array((104.00698793,116.66876762,122.67891434))
  in_ = in_.transpose((2,0,1))
  return in_;



# Pass image through network
def runImageThroughNetwork(img, net):
  # shape for input (data blob is N x C x H x W), set data
  net.blobs['data'].reshape(1, *img.shape)
  net.blobs['data'].data[...] = img

  # run net and take argmax for prediction
  net.forward()
  out = net.blobs

  return out;



# Pass image through network
def getImagePngMask(out, pallete, imageFile, pathForMaskOutFiles):
  index = imageFile.rfind('/') + 1
  imageName = imageFile[index:]
  
  # out_img = np.uint8(out['score'].data[0].argmax(axis=0))
  out_img = np.uint8(out['upscore'].data[0].argmax(axis=0))
  out_img = Image.fromarray(out_img)
  out_img.putpalette(pallete)
  seg = pathForMaskOutFiles + "/" + imageName.replace(".jpg", ".png")
  out_img.save(seg)
  return



# Pass image through network
def getImageTextMask(out, fullImageName, textFilePath):
  index = fullImageName.rfind('/') + 1
  imageName = fullImageName[index:]
  output = out['upscore'].data[0].argmax(axis=0)
  numrows = len(output)
  numcols = len(output[0])
  
  # Open and write file
  np.savetxt(textFilePath+"/"+imageName + ".txt", output, fmt='%d', delimiter=' ', newline='\n', header='', footer='', comments='# ')
  
  return 


# save a png mask that distinguishes between sky and other pixels
def getImagePngMaskSky(out, pallete, imageFile, pathForMaskOutFiles):
  index = imageFile.rfind('/') + 1
  imageName = imageFile[index:]
  
  out_img = np.uint8(out['upscore'].data[0].argmax(axis=0))
  out_img[out_img!=27] = 1
  out_img = Image.fromarray(out_img)
  out_img.putpalette(pallete)
  seg = pathForMaskOutFiles + "/" + imageName.replace(".jpg", ".png")
  out_img.save(seg)
  return


# return a png mask that distinguishes between sky and other pixels
def getImagePngMaskSky(out, pallete, imageFile, pathForMaskOutFiles):
    index = imageFile.rfind('/') + 1
    imageName = imageFile[index:]

    out_img = np.uint8(out['upscore'].data[0].argmax(axis=0))
    out_img[out_img != 27] = 1
    out_img = Image.fromarray(out_img)
    out_img.putpalette(pallete)
    seg = pathForMaskOutFiles + "/" + imageName.replace(".jpg", ".png")
    out_img.save(seg)
    return


# Pass image through network to recognize 'sky' label (num 27)
def getImageTextMaskSky(out, fullImageName, textFilePath):
  index = fullImageName.rfind('/') + 1
  imageName = fullImageName[index:]
  output = out['upscore'].data[0].argmax(axis=0)
  output[output!=27] = 1
  numrows = len(output)
  numcols = len(output[0])
  
  # Open and write file
  np.savetxt(textFilePath+"/"+imageName + ".txt", output, fmt='%d', delimiter=' ', newline='\n', header='', footer='', comments='# ')
  
  return 



# Pass image through network to recognize 'sky' label (num 27)
def calculatingRGratioForSkyRegion(fullImageName, textFilePath):
  index = fullImageName.rfind('/') + 1
  imageName = fullImageName[index:]
  
  # Open image file
  im = Image.open(fullImageName) 
  pix = im.load()
  
  # Open txt mask file
  var = []
  with open(textFilePath+"/"+imageName + ".txt") as file:
     array2d = [[int(digit) for digit in line.strip().split(' ')] for line in file]
  
  numrows = len(array2d)
  numcols = len(array2d[0])
  
  
  # Get RGB values for pixesl with label = 27 and get sum of R and G
  sumR = 0
  sumG = 0
  for i in range(0, numrows):
    for j in range(0, numcols):
      if int(array2d[i][j]) == 27:
	sumR = sumR + pix[i,j][0]
	sumG = sumG + pix[i,j][1]

  #print im.size
    
  ration = float(sumR)/sumG
    
  return ration




# MAIN PROGRAM


# Pallete of colours
pallete = [ 0,0,0,
	0, 255, 255,
	0, 102, 153,
	0, 51, 204,
	51, 51, 153,
	0, 102, 102,
	0, 153, 204,
	0, 0, 255,
	102, 102, 153,
	51, 153, 102,
	0, 255, 204,
	102, 153, 255,
	102, 0, 255,
	102, 0, 204,
	0, 204, 102,
	153, 204, 255,
	153, 51, 255,
	0, 153, 51,
	255, 255, 255,
	255, 153, 255,
	255, 0, 255,
	102, 0, 102,
	255, 153, 204,
	255, 255, 204,
	51, 51, 0,
	153, 204, 0,
	255, 102, 102,
	255, 153, 102,
	204, 102, 153,
	102, 0, 51,
	255, 102, 0,
	153, 153, 102,
	255, 51, 0,
	255, 0, 0,
	204, 153, 0,
	204, 153, 0,
	128, 0, 0,
	153, 51, 0]



# Get arguments
print('Number of arguments:', len(sys.argv), 'arguments.')
print('Argument List:', sys.argv)


fileWithImages = sys.argv[1]
protoTxt = sys.argv[2]
modelFile = sys.argv[3]
pathForTxtOutFiles = sys.argv[4]
pathForMaskOutFiles = sys.argv[5]
fileWithImagesRGRatio = sys.argv[6]



# Load net
net = caffe.Net(protoTxt, modelFile, caffe.TEST)


# Get time start
start = int(time.time() * 1000)



# Open file to write images RG ratio
target = open(fileWithImagesRGRatio, 'w')


# Read file with images into a list
with open(fileWithImages) as f:
  for line in f:
    image = line.rstrip('\n')
    img = loadImage(image)
    out = runImageThroughNetwork(img, net)
    
    ## Image mask and text and consider all labels
    #getImagePngMask(out, pallete, image, pathForMaskOutFiles);
    #getImageTextMask(out, image, pathForTxtOutFiles);
    
    # Image mask and text and consider only sky label
    getImagePngMaskSky(out, pallete, image, pathForMaskOutFiles);
    getImageTextMaskSky(out, image, pathForTxtOutFiles);
    
    
    # Getting RG ratio
    RG_ration = calculatingRGratioForSkyRegion(image, pathForTxtOutFiles)
    
    target.write(image + " " + str(RG_ration) + "\n")

  

# Close file with images RG ratio
target.close()

# Get time start
end = int(time.time() * 1000)


secondsPassed = (end-start)/1000
print("Time elapsed in seconds: %d" % secondsPassed)
